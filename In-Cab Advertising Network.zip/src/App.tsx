import { useState, useEffect, useRef, type ReactNode } from "react";

/* ── Images ─────────────────────────────────────── */
const IMG = {
  carInterior:
    "https://images.unsplash.com/photo-1678707407526-06201ed279e9?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=88&w=900&h=1100",
  jaipurCity:
    "https://images.unsplash.com/photo-1770310607863-2ceb47c6b18e?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=88&w=900&h=500",
  delhiCity:
    "https://images.unsplash.com/photo-1788364749743-9770df151370?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=88&w=900&h=500",
};

/* ── Types ───────────────────────────────────────── */
type IconName =
  | "arrow" | "check" | "clock" | "eye" | "location"
  | "menu" | "play" | "route" | "screen" | "shield"
  | "signal" | "upload" | "map";
type City = "jaipur" | "delhi";

/* ── City data ───────────────────────────────────── */
const CITIES: Record<City, {
  name: string;
  greeting: string;
  subtitle: string;
  heroBody: string;
  landmark: string;
  windowAlt: string;
  adLines: [string, string];
  stats: [string, string][];
  transport: { label: string; value: string; width: string }[];
  hotspots: { name: string; area: string; volume: string; level: number }[];
  marketTitle: string;
  marketBody: string;
  pilotLabel: string;
  pilotCTA: string;
  footerCaption: string;
  accentHue: string;
}> = {
  jaipur: {
    name: "Jaipur",
    greeting: "Hello Jaipur",
    subtitle: "The Pink City's in-cab media network",
    heroBody:
      "Turn every cab ride through Chandpole or Apex Circle into 20–30 minutes of high-intent brand attention. Hyper-local, GPS-verified, live in 48 hours.",
    landmark: "Hawa Mahal corridor",
    windowAlt: "Jaipur's pink city streets seen through cab windscreen",
    adLines: ["Discover Jaipur", "Amber Fort"],
    stats: [
      ["3.5M+", "registered vehicles"],
      ["1.5M+", "daily road journeys"],
      ["600K+", "aggregator trips"],
      ["58%", "congestion index"],
    ],
    transport: [
      { label: "Personal vehicles", value: "1.8–2.2M", width: "100%" },
      { label: "App autos",         value: "300–400K",  width: "46%" },
      { label: "Bike taxis",        value: "150–200K",  width: "29%" },
      { label: "City buses",        value: "125–160K",  width: "22%" },
      { label: "App cabs",          value: "100–150K",  width: "19%" },
    ],
    hotspots: [
      { name: "Chandpole",   area: "Walled City",     volume: "330K", level: 96 },
      { name: "Apex Circle", area: "Malviya Nagar",   volume: "290K", level: 84 },
      { name: "Ramganj",     area: "Trading district",volume: "280K", level: 80 },
      { name: "JDA Circle",  area: "JLN Marg",        volume: "180K", level: 52 },
      { name: "Sindhi Camp", area: "Transit gateway", volume: "180K", level: 52 },
    ],
    marketTitle: "A city in motion. A market in sight.",
    marketBody:
      "Millions of daily journeys converge on a handful of high-value corridors — creating repeatable, measurable moments for brands across the Pink City.",
    pilotLabel: "Jaipur pilot now open",
    pilotCTA: "Launch in Jaipur",
    footerCaption:
      "Jaipur's privacy-first in-cab digital-out-of-home network. Real streets, real journeys, measurable attention.",
    accentHue: "from-rose-950",
  },
  delhi: {
    name: "Delhi",
    greeting: "Hello Delhi",
    subtitle: "The Capital's in-cab media network",
    heroBody:
      "Own the commute from Chandni Chowk to Connaught Place. 20–30 minutes of captive attention, GPS-verified across every major Delhi corridor, live in 48 hours.",
    landmark: "Red Fort & India Gate corridors",
    windowAlt: "Red Fort illuminated at night seen through cab windscreen",
    adLines: ["Explore Old Delhi", "Connaught Place"],
    stats: [
      ["11M+", "registered vehicles"],
      ["4M+",  "daily road journeys"],
      ["1.2M+","aggregator trips"],
      ["62%",  "congestion index"],
    ],
    transport: [
      { label: "Personal vehicles", value: "6–7M",     width: "100%" },
      { label: "App cabs & autos",  value: "500–700K", width: "50%" },
      { label: "Metro feeders",     value: "400–500K", width: "38%" },
      { label: "City buses (DTC)",  value: "350–450K", width: "34%" },
      { label: "Bike taxis",        value: "200–280K", width: "26%" },
    ],
    hotspots: [
      { name: "Chandni Chowk",  area: "Old Delhi",      volume: "480K", level: 99 },
      { name: "Connaught Place", area: "Central Delhi",  volume: "380K", level: 79 },
      { name: "Karol Bagh",     area: "West Delhi",     volume: "290K", level: 60 },
      { name: "Lajpat Nagar",   area: "South Delhi",    volume: "210K", level: 44 },
      { name: "Nehru Place",    area: "South Delhi",    volume: "190K", level: 40 },
    ],
    marketTitle: "The capital in motion. The market in sight.",
    marketBody:
      "From Old Delhi's ancient lanes to South Delhi's tech corridors — 4 million daily journeys create unmissable captive brand moments at scale.",
    pilotLabel: "Delhi launch coming soon",
    pilotCTA: "Reserve Delhi slots",
    footerCaption:
      "Delhi's privacy-first in-cab digital-out-of-home network. Capital streets, capital journeys, measurable attention.",
    accentHue: "from-indigo-950",
  },
};

/* ── Scroll reveal hook ──────────────────────────── */
function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("revealed");
            if (entry.target.classList.contains("stat-num")) {
              entry.target.classList.add("count-revealed");
            }
          }
        });
      },
      { threshold: 0.12 },
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

/* ── Icon ─────────────────────────────────────────── */
function Icon({ name, className = "size-5" }: { name: IconName; className?: string }) {
  const paths: Record<IconName, ReactNode> = {
    arrow:    <path d="M5 12h14m-5-5 5 5-5 5" />,
    check:    <path d="m5 12 4 4L19 6" />,
    clock:    <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    eye:      <><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" /><circle cx="12" cy="12" r="2.5" /></>,
    location: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    menu:     <path d="M4 7h16M4 12h16M4 17h16" />,
    play:     <path d="m9 7 8 5-8 5V7Z" />,
    route:    <><circle cx="6" cy="18" r="2" /><circle cx="18" cy="6" r="2" /><path d="M8 18h3a3 3 0 0 0 3-3V9a3 3 0 0 1 3-3" /></>,
    screen:   <><rect x="3" y="4" width="18" height="13" rx="2" /><path d="M8 21h8m-4-4v4" /></>,
    shield:   <path d="M12 3 4.5 6v5c0 4.8 3.2 8.1 7.5 10 4.3-1.9 7.5-5.2 7.5-10V6L12 3Zm-3 9 2 2 4-4" />,
    signal:   <path d="M4 17v2m5-6v6m5-10v10m5-15v15" />,
    upload:   <><path d="M12 16V4m-4 4 4-4 4 4" /><path d="M5 14v5h14v-5" /></>,
    map:      <><path d="M3 7l6-3 6 3 6-3v13l-6 3-6-3-6 3V7Z" /><path d="M9 4v13M15 7v13" /></>,
  };
  return (
    <svg aria-hidden="true" className={className} fill="none" viewBox="0 0 24 24"
      stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      {paths[name]}
    </svg>
  );
}

/* ── Ornamental SVG divider ─────────────────────── */
function OrnamentDivider({ light = false }: { light?: boolean }) {
  const col = light ? "rgba(255,255,255,0.25)" : "rgba(201,168,76,0.35)";
  return (
    <div className="flex items-center justify-center gap-3 py-2">
      <svg width="60" height="12" viewBox="0 0 60 12" fill="none">
        <path d="M0 6 Q15 0 30 6 Q45 12 60 6" stroke={col} strokeWidth="1" fill="none" />
      </svg>
      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
        <path d="M5 0 L10 5 L5 10 L0 5 Z" fill={col} />
      </svg>
      <svg width="60" height="12" viewBox="0 0 60 12" fill="none">
        <path d="M0 6 Q15 12 30 6 Q45 0 60 6" stroke={col} strokeWidth="1" fill="none" />
      </svg>
    </div>
  );
}

/* ── Royal ornament bg ──────────────────────────── */
function RoyalArch() {
  return (
    <div className="pointer-events-none absolute right-0 top-0 opacity-[0.035] ornament-spin" style={{ width: 440, height: 440, right: -100, top: -100 }}>
      <svg viewBox="0 0 440 440" fill="none">
        <circle cx="220" cy="220" r="200" stroke="#c9a84c" strokeWidth="1" />
        <circle cx="220" cy="220" r="168" stroke="#c9a84c" strokeWidth="1" />
        {Array.from({ length: 16 }).map((_, i) => {
          const angle = (i * 360) / 16;
          const rad = (angle * Math.PI) / 180;
          const x1 = 220 + 168 * Math.cos(rad);
          const y1 = 220 + 168 * Math.sin(rad);
          const x2 = 220 + 200 * Math.cos(rad);
          const y2 = 220 + 200 * Math.sin(rad);
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#c9a84c" strokeWidth="1" />;
        })}
        <path d="M220 20 L240 200 L220 220 L200 200 Z" stroke="#c9a84c" strokeWidth="1" fill="none" />
        <path d="M220 420 L240 240 L220 220 L200 240 Z" stroke="#c9a84c" strokeWidth="1" fill="none" />
        <path d="M20 220 L200 240 L220 220 L200 200 Z" stroke="#c9a84c" strokeWidth="1" fill="none" />
        <path d="M420 220 L240 240 L220 220 L240 200 Z" stroke="#c9a84c" strokeWidth="1" fill="none" />
      </svg>
    </div>
  );
}

/* ── Brand ───────────────────────────────────────── */
function Brand({ inverse = false }: { inverse?: boolean }) {
  return (
    <a href="#top" className="group flex items-center gap-3" aria-label="What You Don't Want to See home">
      <span className="grid size-10 place-items-center rounded-full bg-accent text-ink transition-transform group-hover:-rotate-6">
        <Icon name="eye" className="size-5" />
      </span>
      <span className="leading-tight">
        <span className="block text-[0.65rem] font-bold uppercase tracking-[0.18em] text-muted">What you don't</span>
        <span className={`block font-display text-[1.05rem] font-bold ${inverse ? "text-white" : "text-ink"}`}>want to see</span>
      </span>
    </a>
  );
}

/* ── Button ──────────────────────────────────────── */
function Button({ children, href, secondary = false }: { children: ReactNode; href: string; secondary?: boolean }) {
  return (
    <a className={`button ${secondary ? "button-secondary" : ""}`} href={href}>
      {children}
    </a>
  );
}

/* ── Section title ───────────────────────────────── */
function SectionTitle({ eyebrow, title, body, light = false }: {
  eyebrow: string; title: string; body?: string; light?: boolean;
}) {
  return (
    <div className="max-w-3xl">
      <p className={`eyebrow ${light ? "text-accent" : "text-coral"}`}>{eyebrow}</p>
      <h2 className={`section-title ${light ? "text-white" : "text-ink"}`}>{title}</h2>
      {body && <p className={`mt-5 text-lg leading-8 ${light ? "text-white/65" : "text-muted"}`}>{body}</p>}
    </div>
  );
}

/* ── Composite hero image ────────────────────────── */
function HeroImage({ city }: { city: City }) {
  const d = CITIES[city];
  return (
    <div className="relative mx-auto h-[34rem] w-full max-w-xl lg:h-[44rem]">
      {/* Main card */}
      <div className="absolute inset-x-8 bottom-0 top-4 overflow-hidden rounded-[2.5rem] shadow-hero" style={{ background: "#0d0515" }}>

        {/* Car interior base */}
        <img
          className="absolute inset-0 h-full w-full object-cover object-center"
          style={{ opacity: 0.55 }}
          src={IMG.carInterior}
          alt="Luxury cab interior"
        />

        {/* Windscreen – city view through car window */}
        <div
          className="absolute left-5 right-5 top-5 overflow-hidden city-fade"
          style={{ height: "50%", borderRadius: "1.25rem 1.25rem 2.5rem 2.5rem" }}
        >
          <img
            key={city}
            className="h-full w-full object-cover"
            src={city === "jaipur" ? IMG.jaipurCity : IMG.delhiCity}
            alt={d.windowAlt}
          />
          {/* Windscreen tint */}
          <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(13,5,21,0.1), rgba(13,5,21,0.55))" }} />
          {/* Windscreen glass reflection */}
          <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.09) 0%, transparent 50%)" }} />
          {/* Windscreen inner frame */}
          <div className="absolute inset-0 rounded-[inherit]" style={{ boxShadow: "inset 0 0 0 2px rgba(255,255,255,0.1)" }} />
          {/* Landmark label */}
          <div className="absolute bottom-3 right-4 flex items-center gap-1.5 rounded-full px-3 py-1 text-[0.6rem] font-bold uppercase tracking-wider text-white/70" style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(8px)" }}>
            <Icon name="location" className="size-3 text-accent" />
            {d.landmark}
          </div>
        </div>

        {/* In-cab ad screen */}
        <div
          className="absolute city-fade"
          style={{ bottom: "37%", left: "50%", transform: "translateX(-50%)", width: "7rem", height: "4.5rem", zIndex: 10 }}
        >
          <div className="relative h-full w-full overflow-hidden rounded-xl border border-white/20 shadow-2xl" style={{ background: "#080010" }}>
            {/* Slide A */}
            <div className="ad-slide-a absolute inset-0 flex flex-col items-center justify-center p-2 text-center"
              style={{ background: "linear-gradient(135deg, #8b1a4e, #c9184a)" }}>
              <span className="text-[0.5rem] font-bold uppercase tracking-[0.15em] text-accent/90">Now Playing</span>
              <span className="mt-0.5 font-display text-[0.75rem] font-semibold leading-tight text-white">{d.adLines[0]}</span>
            </div>
            {/* Slide B */}
            <div className="ad-slide-b absolute inset-0 flex flex-col items-center justify-center p-2 text-center"
              style={{ background: "linear-gradient(135deg, #1a0935, #4a1a6e)" }}>
              <span className="text-[0.5rem] font-bold uppercase tracking-[0.15em] text-accent/90">Sponsored</span>
              <span className="mt-0.5 font-display text-[0.75rem] font-semibold leading-tight text-white">{d.adLines[1]}</span>
            </div>
            {/* Screen shine */}
            <div className="absolute inset-0 rounded-xl" style={{ background: "linear-gradient(120deg, rgba(255,255,255,0.18) 0%, transparent 55%)", pointerEvents: "none" }} />
          </div>
        </div>

        {/* Bottom gradient overlay */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(13,5,21,0.92) 0%, rgba(13,5,21,0.3) 50%, transparent 100%)" }} />

        {/* Caption */}
        <div className="absolute bottom-0 inset-x-0 p-7 text-white">
          <p className="text-[0.65rem] font-bold uppercase tracking-[0.2em] text-accent">Live context</p>
          <p className="mt-2 font-display text-2xl font-semibold leading-snug city-fade" key={city}>
            {city === "jaipur" ? <>Jaipur moves.<br />Your brand moves with it.</> : <>Delhi moves.<br />Your brand leads the way.</>}
          </p>
        </div>
      </div>

      {/* Floating stat card */}
      <div className="float-card absolute left-0 top-16 rounded-2xl bg-white p-4 shadow-card">
        <div className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-xl bg-mint text-ink"><Icon name="route" /></span>
          <span>
            <strong className="block text-xl">{city === "jaipur" ? "3.2 km" : "5.8 km"}</strong>
            <small className="text-muted">peak 15-min distance</small>
          </span>
        </div>
      </div>

      {/* Floating attention card */}
      <div className="float-card-delayed absolute bottom-28 right-0 w-48 rounded-2xl p-5 text-ink shadow-card" style={{ background: "var(--color-accent)" }}>
        <div className="flex justify-between text-xs font-bold uppercase tracking-wider">
          <span>Attention</span>
          <Icon name="eye" className="size-4" />
        </div>
        <strong className="mt-4 block font-display text-4xl">100%</strong>
        <p className="mt-1 text-sm font-medium text-ink/65">viewable placement</p>
      </div>
    </div>
  );
}

/* ── City switcher ───────────────────────────────── */
function CitySwitcher({ city, onChange }: { city: City; onChange: (c: City) => void }) {
  return (
    <div className="city-switcher" role="group" aria-label="Select city">
      {(["jaipur", "delhi"] as City[]).map((c) => (
        <button key={c} className={`city-btn ${city === c ? "active" : ""}`} onClick={() => onChange(c)}>
          <span className="dot" />
          {c === "jaipur" ? "Jaipur" : "Delhi"}
        </button>
      ))}
    </div>
  );
}

/* ── Value cards data ────────────────────────────── */
const VALUES = [
  { icon: "eye" as IconName,      title: "Unmissable attention",     text: "HD screens sit in the passenger's natural line of sight throughout the ride.",               stat: "20+ min", label: "average attention window" },
  { icon: "location" as IconName, title: "Street-level targeting",   text: "Own the exact neighborhoods, commute corridors, and dayparts that matter to your brand.",     stat: "GPS",     label: "verified zone delivery" },
  { icon: "signal" as IconName,   title: "Control in real time",     text: "Launch, pause, swap creative, and monitor live fleet coverage from one unified dashboard.",   stat: "48 hr",   label: "creative to live campaign" },
];

/* ── App ─────────────────────────────────────────── */
function App() {
  const [city, setCity] = useState<City>("jaipur");
  const d = CITIES[city];

  useScrollReveal();

  function handleCityChange(c: City) {
    setCity(c);
    // re-trigger reveals after city switch
    setTimeout(() => {
      document.querySelectorAll(".reveal").forEach((el) => el.classList.remove("revealed"));
      setTimeout(() => {
        const observer = new IntersectionObserver(
          (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("revealed"); }),
          { threshold: 0.1 },
        );
        document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
      }, 80);
    }, 50);
  }

  const marqueeItems = ["3.5M+ Vehicles", "1.5M+ Daily Journeys", "48hr Campaign Launch", "GPS Verified", "Privacy First", "HD In-Cab Screens", "Real-Time Dashboard"];

  return (
    <main id="top" className="overflow-hidden jali-bg" style={{ background: "var(--color-canvas)" }}>

      {/* ── Header ───────────────────────────────── */}
      <header className="absolute inset-x-0 top-0 z-30">
        <div className="page-wrap flex h-24 items-center justify-between gap-4">
          <Brand />
          <nav className="hidden items-center gap-8 text-sm font-semibold text-ink/70 md:flex" aria-label="Main navigation">
            <a className="nav-link" href="#why">Why it works</a>
            <a className="nav-link" href="#market">The market</a>
            <a className="nav-link" href="#process">How it works</a>
          </nav>
          <div className="hidden items-center gap-3 md:flex">
            <CitySwitcher city={city} onChange={handleCityChange} />
            <Button href="#contact">Plan a campaign <Icon name="arrow" className="size-4" /></Button>
          </div>
          <a href="#contact" className="grid size-11 place-items-center rounded-full border border-ink/15 md:hidden" aria-label="Jump to campaign enquiry">
            <Icon name="menu" />
          </a>
        </div>
      </header>

      {/* ── Hero ─────────────────────────────────── */}
      <section className="relative min-h-[54rem] pt-36 lg:min-h-screen">
        <div className="hero-orb" />
        <div className="hero-orb-2" />
        <RoyalArch />

        <div className="page-wrap relative grid items-center gap-12 lg:grid-cols-[1.08fr_0.92fr]">
          <div className="relative z-10 pb-8 pt-10 lg:pb-24 lg:pt-16">

            {/* Gold shimmer badge */}
            <div className="shimmer mb-6 inline-flex items-center gap-2 rounded-full border border-accent/30 px-4 py-2 text-xs font-bold uppercase tracking-[0.14em] text-royal shadow-soft" style={{ background: "rgba(201,168,76,0.1)", backdropFilter: "blur(10px)" }}>
              <span className="pulse-dot relative size-2 rounded-full" style={{ background: "var(--color-royal)" }} />
              <span className="city-fade" key={city}>{d.subtitle}</span>
            </div>

            {/* "Hello Jaipur/Delhi" — large royal display */}
            <div className="city-fade leading-none" key={`greeting-${city}`}>
              <p
                className="font-royal italic"
                style={{
                  fontSize: "clamp(3.2rem, 8vw, 5.8rem)",
                  color: "var(--color-accent)",
                  letterSpacing: "-0.02em",
                  lineHeight: 0.95,
                  marginBottom: "-0.1em",
                }}
              >
                {d.greeting.split(" ")[0]}
              </p>
              <p
                className="font-royal font-semibold italic"
                style={{
                  fontSize: "clamp(3.5rem, 9vw, 6.4rem)",
                  color: "var(--color-royal)",
                  letterSpacing: "-0.025em",
                  lineHeight: 0.9,
                }}
              >
                {d.greeting.split(" ")[1]}
              </p>
            </div>

            {/* Main h1 — flows visually from greeting */}
            <h1 className="mt-4 max-w-4xl font-display text-5xl font-semibold leading-[0.94] tracking-[-0.055em] text-ink sm:text-6xl lg:text-[5.4rem]">
              Your next customer is already{" "}
              <span className="relative text-coral">
                looking.
                <svg className="absolute -bottom-3 left-0 w-full text-accent" viewBox="0 0 240 12" fill="none">
                  <path d="M2 8c58-7 154-7 236-3" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
                </svg>
              </span>
            </h1>

            <p className="city-fade mt-9 max-w-xl text-lg leading-8 text-muted" key={`body-${city}`}>{d.heroBody}</p>

            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Button href="#contact">{d.pilotCTA} <Icon name="arrow" className="size-4" /></Button>
              <Button href="#process" secondary><Icon name="play" className="size-4" /> See how it works</Button>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-x-7 gap-y-3 text-sm font-semibold text-muted">
              <span className="flex items-center gap-2"><Icon name="check" className="size-4 text-royal" /> No cameras</span>
              <span className="flex items-center gap-2"><Icon name="check" className="size-4 text-royal" /> No print cost</span>
            </div>

            {/* Mobile city switcher */}
            <div className="mt-8 md:hidden">
              <CitySwitcher city={city} onChange={handleCityChange} />
            </div>
          </div>

          <HeroImage city={city} />
        </div>
      </section>

      {/* ── Marquee stats ticker ─────────────────── */}
      <div className="border-y border-ink/10 bg-ink/[0.03] py-3">
        <div className="marquee-wrap">
          <div className="marquee-track">
            {[...marqueeItems, ...marqueeItems].map((item, i) => (
              <span key={i} className="flex items-center gap-6 px-6 text-xs font-bold uppercase tracking-[0.15em] text-muted">
                <span className="size-1 rounded-full bg-accent/60" />
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* ── Stats bar ────────────────────────────── */}
      <section className="border-b border-ink/10 bg-white">
        <div className="page-wrap grid grid-cols-2 divide-x divide-y divide-ink/10 md:grid-cols-4 md:divide-y-0">
          {d.stats.map(([stat, label]) => (
            <div key={label} className="reveal stat-num px-4 py-9 text-center first:pl-0 last:pr-0">
              <strong className="font-display text-3xl font-semibold text-ink md:text-4xl">{stat}</strong>
              <p className="mt-1 text-xs font-bold uppercase tracking-[0.12em] text-muted">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Value props ──────────────────────────── */}
      <section id="why" className="page-wrap py-24 lg:py-32">
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
          <div className="reveal">
            <SectionTitle eyebrow="Built for attention" title="Digital speed. Outdoor impact." body="Everything advertisers love about performance media, delivered in a place customers can't scroll past." />
          </div>
          <p className="reveal reveal-delay-2 max-w-xs text-sm leading-6 text-muted">A privacy-first alternative to billboards, mobile ads, and rigid cinema inventory.</p>
        </div>
        <OrnamentDivider />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {VALUES.map((item, index) => (
            <article key={item.title} className={`value-card reveal reveal-delay-${index + 1} ${index === 1 ? "bg-ink text-white" : "bg-white text-ink"}`}>
              <div className="flex items-start justify-between">
                <span className={`grid size-12 place-items-center rounded-2xl ${index === 1 ? "bg-accent text-ink" : "bg-blush text-coral"}`}>
                  <Icon name={item.icon} />
                </span>
                <span className={`text-xs font-bold ${index === 1 ? "text-white/35" : "text-muted/50"}`}>0{index + 1}</span>
              </div>
              <h3 className="mt-12 font-display text-2xl font-semibold">{item.title}</h3>
              <p className={`mt-3 leading-7 ${index === 1 ? "text-white/60" : "text-muted"}`}>{item.text}</p>
              <div className={`mt-10 border-t pt-6 ${index === 1 ? "border-white/15" : "border-ink/10"}`}>
                <strong className="font-display text-3xl font-semibold text-coral">{item.stat}</strong>
                <p className={`mt-1 text-xs font-bold uppercase tracking-wider ${index === 1 ? "text-white/40" : "text-muted"}`}>{item.label}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ── Market data ──────────────────────────── */}
      <section id="market" className="jali-bg-light py-24 lg:py-32" style={{ background: "var(--color-ink)" }}>
        <div className="page-wrap">
          <div className="reveal">
            <SectionTitle light eyebrow={`The ${d.name} opportunity`} title={d.marketTitle} body={d.marketBody} />
          </div>
          <OrnamentDivider light />
          <div className="mt-12 grid gap-6 lg:grid-cols-[1.08fr_0.92fr]">

            {/* Transport bars */}
            <article className="reveal rounded-[2rem] bg-white/5 p-6 ring-1 ring-white/10 sm:p-9">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.16em] text-white/40">Daily passenger volume</p>
                  <h3 className="mt-2 font-display text-2xl font-semibold text-white city-fade" key={`transport-${city}`}>How {d.name} gets around</h3>
                </div>
                <span className="hidden rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold text-white/60 sm:block">Estimated daily</span>
              </div>
              <div className="mt-10 space-y-6 city-fade" key={`bars-${city}`}>
                {d.transport.map((bar, i) => (
                  <div key={bar.label} className={`reveal reveal-delay-${i + 1}`}>
                    <div className="mb-2 flex justify-between text-sm">
                      <span className="font-medium text-white/65">{bar.label}</span>
                      <strong className="text-white">{bar.value}</strong>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-white/10">
                      <div className="h-full rounded-full transition-all duration-700" style={{ width: bar.width, background: "var(--color-coral)" }} />
                    </div>
                  </div>
                ))}
              </div>
              <p className="mt-9 border-t border-white/10 pt-6 text-sm leading-6 text-white/40">Indicative ranges based on urban transport assessments and aggregator operating estimates.</p>
            </article>

            {/* Hotspots */}
            <article className="reveal reveal-delay-2 rounded-[2rem] p-6 text-ink sm:p-9" style={{ background: "var(--color-accent)" }}>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-ink/50">Top vehicle hotspots</p>
              <h3 className="mt-2 font-display text-2xl font-semibold city-fade" key={`hotspot-title-${city}`}>Where {d.name} concentrates</h3>
              <div className="mt-8 divide-y divide-ink/10 city-fade" key={`hotspots-${city}`}>
                {d.hotspots.map((spot, index) => (
                  <div key={spot.name} className="grid grid-cols-[2rem_1fr_auto] items-center gap-3 py-4">
                    <span className="text-xs font-bold text-ink/35">0{index + 1}</span>
                    <div>
                      <div className="flex items-center gap-3">
                        <strong className="text-sm">{spot.name}</strong>
                        <span className="hidden text-xs text-ink/45 sm:inline">{spot.area}</span>
                      </div>
                      <div className="mt-2 h-1 max-w-[13rem] overflow-hidden rounded-full bg-ink/10">
                        <div className="h-full rounded-full bg-ink transition-all duration-700" style={{ width: `${spot.level}%` }} />
                      </div>
                    </div>
                    <strong className="font-display text-lg">{spot.volume}<small className="ml-1 font-sans text-[0.6rem] uppercase text-ink/40">/day</small></strong>
                  </div>
                ))}
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* ── Process ──────────────────────────────── */}
      <section id="process" className="page-wrap py-24 lg:py-32">
        <div className="grid gap-16 lg:grid-cols-[0.8fr_1.2fr]">
          <div className="reveal lg:sticky lg:top-10 lg:self-start">
            <SectionTitle eyebrow="Simple by design" title="From artwork to everywhere." body="No agencies, no printing, no long lead times. Set your campaign once and adjust as the city moves." />
            <OrnamentDivider />
            <div className="mt-4">
              <Button href="#contact">Start your campaign <Icon name="arrow" className="size-4" /></Button>
            </div>
          </div>
          <div className="space-y-4">
            {([
              ["01", "Brief & target",   "Choose your neighborhoods, audience, dates, and high-value commute windows.",             "location"],
              ["02", "Format & verify",  "Upload existing artwork or let our team optimize it for in-cab HD screens.",               "upload"],
              ["03", "Go live & track",  "Your campaign is pushed wirelessly to active cabs, with route and coverage data live.",    "signal"],
            ] as [string, string, string, IconName][]).map(([number, title, text, icon], i) => (
              <article key={number} className={`process-card group reveal reveal-delay-${i + 1}`}>
                <span className="font-display text-5xl font-semibold text-ink/10 transition-colors group-hover:text-royal/25">{number}</span>
                <div>
                  <h3 className="font-display text-2xl font-semibold">{title}</h3>
                  <p className="mt-2 max-w-md leading-7 text-muted">{text}</p>
                </div>
                <span className="grid size-12 place-items-center rounded-full bg-canvas text-royal transition-colors group-hover:bg-royal group-hover:text-white">
                  <Icon name={icon} />
                </span>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ── Competitive positioning ──────────────── */}
      <section className="page-wrap pb-24 lg:pb-32">
        <div className="reveal grid overflow-hidden rounded-[2.5rem] bg-blush lg:grid-cols-2">
          <div className="p-8 sm:p-12 lg:p-16">
            <p className="eyebrow text-royal">Why now</p>
            <h2 className="section-title text-ink">The media gap is the opportunity.</h2>
            <div className="mt-8 space-y-5">
              {([
                ["Billboards",   "Static, expensive, and difficult to attribute."],
                ["Online ads",   "Skipped, blocked, and lost in crowded feeds."],
                ["In-cab DOOH",  "Captive, contextual, flexible, and verified."],
              ] as [string, string][]).map(([title, text], index) => (
                <div key={title} className={`flex gap-4 rounded-2xl p-4 ${index === 2 ? "bg-white shadow-soft" : ""}`}>
                  <span className={`mt-0.5 grid size-8 shrink-0 place-items-center rounded-full ${index === 2 ? "bg-royal text-white" : "bg-ink/5 text-muted"}`}>
                    {index === 2 ? <Icon name="check" className="size-4" /> : <span className="h-px w-3 bg-current" />}
                  </span>
                  <div>
                    <strong>{title}</strong>
                    <p className="mt-1 text-sm leading-6 text-muted">{text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative min-h-[28rem] p-8 text-white sm:p-12 lg:p-16" style={{ background: "var(--color-royal)" }}>
            <div className="absolute -right-20 -top-20 size-64 rounded-full border-[3rem] border-white/10" />
            <div className="absolute -left-10 -bottom-10 size-40 rounded-full border-[2rem] border-white/5" />
            <Icon name="eye" className="size-14 text-accent" />
            <blockquote className="relative mt-12 font-royal text-3xl font-semibold italic leading-tight sm:text-4xl">
              "Not more impressions. Better moments of attention."
            </blockquote>
            <p className="relative mt-7 max-w-sm leading-7 text-white/70">Capped advertiser density keeps your message memorable, while automatic fleet reallocation protects delivery.</p>
            <div className="relative mt-10 flex items-center gap-3 border-t border-white/20 pt-6 text-sm font-semibold">
              <Icon name="shield" className="size-5 text-accent" />
              Camera-free, privacy-first measurement
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA footer ───────────────────────────── */}
      <section id="contact" className="py-20" style={{ background: "var(--color-accent)" }}>
        <div className="page-wrap flex flex-col justify-between gap-10 md:flex-row md:items-center">
          <div>
            <p className="eyebrow text-ink/50 city-fade" key={`cta-label-${city}`}>{d.pilotLabel}</p>
            <h2 className="max-w-3xl font-display text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
              Put your brand in the passenger seat.
            </h2>
          </div>
          <Button href="mailto:hello@whatyoudontwanttosee.in">Plan a campaign <Icon name="arrow" className="size-4" /></Button>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────── */}
      <footer className="py-12 text-white" style={{ background: "var(--color-ink)" }}>
        <div className="page-wrap flex flex-col gap-10">
          <OrnamentDivider light />
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-center">
            <Brand inverse />
            <p className="max-w-md text-sm leading-6 text-white/40 city-fade" key={`footer-${city}`}>{d.footerCaption}</p>
          </div>
          <div className="flex flex-col justify-between gap-4 border-t border-white/10 pt-7 text-xs text-white/35 sm:flex-row">
            <span>© 2025 What You Don't Want to See</span>
            <span>{d.name}, India · Built for local brands</span>
          </div>
        </div>
      </footer>
    </main>
  );
}

export default App;
